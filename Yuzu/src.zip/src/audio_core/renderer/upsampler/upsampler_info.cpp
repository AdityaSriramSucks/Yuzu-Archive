// SPDX-FileCopyrightText: Copyright 2022 yuzu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include "audio_core/renderer/upsampler/upsampler_info.h"

namespace AudioCore::AudioRenderer {} // namespace AudioCore::AudioRenderer
